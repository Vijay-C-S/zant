# Alembic

This folder contains the Alembic migration environment for the project.

## Common commands

Create a new migration after model changes:
```powershell
alembic revision --autogenerate -m "describe change"
```

Apply the latest migrations:
```powershell
alembic upgrade head
```

Rollback one migration:
```powershell
alembic downgrade -1
```

## Local development shortcut
If you only need the current tables created quickly for SQLite development, run:

```powershell
python create_tables.py
```

## Notes
- Keep `app/models.py` in sync with migration files.
- For production, prefer Alembic migrations over `create_tables.py`.
- If you change the database URL, update `DATABASE_URL` in your environment or `.env` file before running migration commands.
