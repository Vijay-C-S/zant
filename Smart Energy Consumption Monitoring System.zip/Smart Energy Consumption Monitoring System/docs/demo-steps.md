# Demo Steps

1. Start the backend:
   - `uvicorn app.main:app --reload --port 8000`
2. Open Swagger UI:
   - `http://127.0.0.1:8000/docs`
3. Register a household.
4. Register a smart meter for that household.
5. Run the simulator:
   - `python simulator/meter_simulator.py --url http://localhost:8000/readings --meters 2 --interval 10 --duration 60`
6. Check readings and alerts through the API.
7. Open the monthly report and bill estimate endpoints.
8. Run tests:
   - `pytest -q`
