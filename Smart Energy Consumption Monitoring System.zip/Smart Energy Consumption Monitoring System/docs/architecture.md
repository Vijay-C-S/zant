# Architecture

## Overview
The system uses a FastAPI backend to receive smart meter readings from a Python simulator. Data is stored in SQLite for local development and can be moved to PostgreSQL for production.

## Modules
- `app/main.py`: API entrypoint
- `app/models.py`: SQLAlchemy models
- `app/routers/`: REST endpoints for households, meters, readings, alerts, reports
- `app/services/alert_service.py`: alert rules and persistence
- `app/services/analytics_service.py`: Pandas-based aggregation and reporting
- `simulator/meter_simulator.py`: virtual meter sender

## Data Flow
1. Register a household.
2. Register one or more smart meters.
3. Simulator posts reading data every interval.
4. Backend stores the reading.
5. Alert service evaluates thresholds.
6. Analytics service builds daily/weekly/monthly summaries.
7. Reports and bill estimates are returned through APIs.
