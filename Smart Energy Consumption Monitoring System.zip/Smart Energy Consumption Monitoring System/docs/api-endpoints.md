# API Endpoints

## Households
- `POST /households`
- `GET /households`
- `GET /households/{household_id}`
- `GET /households/{household_id}/readings`
- `GET /households/{household_id}/alerts`
- `GET /households/{household_id}/bill-estimate`

## Meters
- `POST /meters`
- `GET /meters`
- `GET /meters/{meter_id}`

## Readings
- `POST /readings`
- `GET /readings/meter/{meter_id}`
- `GET /readings/household/{household_id}`

## Alerts
- `GET /alerts`
- `GET /alerts/household/{household_id}`
- `POST /alerts`
- `PUT /alerts/{alert_id}/resolve`

## Reports
- `GET /reports/monthly/{household_id}`
- `GET /reports/bill-estimate/{household_id}`
