# Copilot Instructions for Smart Energy Consumption Monitoring System

## Project purpose
Build and maintain a beginner-friendly FastAPI backend for smart energy monitoring. The app tracks households, meters, readings, alerts, and reporting for a small demo-friendly system.

## Core stack
- Python 3.10+
- FastAPI for the API layer
- SQLAlchemy for ORM and database access
- Alembic for migrations
- SQLite for local development
- PostgreSQL support via `DATABASE_URL`
- Pandas for analytics and reporting
- Pytest for automated tests
- `requests` for the simulator client

## Working conventions
- Keep changes small, focused, and consistent with existing code style.
- Prefer fixing root causes over surface-level patches.
- Do not rename public paths, models, or endpoints unless required.
- Preserve the current project layout under `app/`, `simulator/`, `tests/`, `alembic/`, and `docs/`.
- Use clear, descriptive names; avoid one-letter variables unless they are standard loop indices.
- Do not add inline comments unless explicitly requested.
- Wrap file paths, commands, and code identifiers in backticks when documenting changes.

## API expectations
- Households, meters, readings, alerts, and reports are the primary domain objects.
- Keep request/response schemas aligned with the routers and SQLAlchemy models.
- Maintain the existing REST style and avoid introducing breaking route changes.
- If adding an endpoint, update the README and `docs/api-endpoints.md` when relevant.

## Database and migrations
- Use SQLAlchemy models in `app/models.py` as the source of truth.
- Prefer Alembic migrations for schema changes.
- Keep `alembic/versions/` in sync with model updates.
- Use `create_tables.py` only as a quick local development helper.

## Alerts and analytics
- Alert logic lives in `app/services/alert_service.py` and should remain deterministic and testable.
- Analytics helpers live in `app/services/analytics_service.py` and should work with either Pandas DataFrames or iterable reading records when practical.
- Keep reporting calculations easy to verify with unit tests.

## Simulator guidance
- The simulator in `simulator/meter_simulator.py` should stay runnable from the command line.
- When changing simulator behavior, keep CLI flags explicit and documented.
- Ensure simulator output remains useful for demos and smoke tests.

## Testing guidance
- Add or update tests in `tests/` when changing behavior.
- Prefer focused tests for routes, services, and analytics.
- Run the narrowest useful test or validation command after edits when possible.

## Documentation guidance
- Update `README.md` for user-facing workflow changes.
- Keep `docs/architecture.md`, `docs/api-endpoints.md`, and `docs/demo-steps.md` aligned with code changes.
- Keep `alembic/README.md` focused on migration usage.

## Safety and quality
- Avoid introducing unnecessary dependencies.
- Do not remove existing behavior unless the task explicitly requires it.
- Keep the app easy for freshers to understand and demo.
- If a requested change is ambiguous, choose the smallest consistent implementation and note assumptions clearly.