# Smart Energy Consumption Monitoring System

A complete beginner-friendly backend for monitoring household electricity usage with FastAPI, SQLAlchemy, Alembic, a smart-meter simulator, alerts, and analytics.

## Overview
This project models a small smart energy platform where:
- households register their account details,
- meters are attached to households,
- readings are ingested through an API,
- alerts are generated for unusual consumption,
- monthly usage and bill estimates are calculated,
- a simulator generates live traffic for demos and testing.

## Features
- Household and meter registration
- Meter reading ingestion through REST APIs
- Automatic alert generation for high usage and spikes
- Monthly summary and bill estimation endpoints
- Python-based simulator for generating realistic readings
- SQLite local setup with optional PostgreSQL support
- Alembic migrations for schema management

## Tech Stack
- **Backend:** FastAPI
- **ORM:** SQLAlchemy
- **Migrations:** Alembic
- **Database:** SQLite for local development, PostgreSQL via `DATABASE_URL`
- **Analytics:** Pandas
- **Simulation:** Python + `requests`
- **Testing:** Pytest

## Project Structure
- `app/` — FastAPI app, database, models, schemas, routers, services
- `alembic/` — Alembic configuration and migration versions
- `simulator/` — smart meter reading generator CLI
- `tests/` — pytest suite
- `docs/` — architecture, API, and demo notes
- `create_tables.py` — quick local database bootstrap helper

## Requirements
- Python 3.10+ recommended
- Windows PowerShell or any shell that can activate the virtual environment
- Internet access for installing Python dependencies

## Quick Start

### 1. Create and activate a virtual environment
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### 2. Install dependencies
```powershell
pip install -r requirements.txt
```

### 3. Create the database schema
Use one of these options:

```powershell
alembic upgrade head
```

If you want the fastest local bootstrap:

```powershell
python create_tables.py
```

### 4. Start the API server
```powershell
uvicorn app.main:app --reload --port 8000
```

### 5. Open the docs
- Swagger UI: `http://127.0.0.1:8000/docs`
- OpenAPI JSON: `http://127.0.0.1:8000/openapi.json`

## Demo Flow
Use this order for a clean demo:
1. Create a household.
2. Register one or more meters for that household.
3. Start the simulator.
4. Watch readings land in the API.
5. Query alerts for the household.
6. Open the monthly report and bill estimate.

## API Summary
The full endpoint list is in `docs/api-endpoints.md`. The main routes are:

- `GET /`
- `POST /households/`
- `GET /households/`
- `GET /households/{household_id}`
- `POST /meters/`
- `GET /meters/`
- `POST /readings/`
- `GET /readings/meter/{meter_id}`
- `GET /alerts/`
- `GET /alerts/household/{household_id}`
- `GET /reports/monthly/{household_id}`
- `GET /reports/bill-estimate/{household_id}`

### Example payloads

Create a household:
```json
{
	"customer_name": "Demo Home",
	"email": "demo@example.com",
	"phone": "1234567890",
	"address": "123 Demo St"
}
```

Register a meter:
```json
{
	"household_id": 1,
	"meter_number": "MTR-1001"
}
```

Post a reading:
```json
{
	"meter_id": 1,
	"energy_consumed_kwh": 1.25,
	"voltage": 230,
	"current": 1.8,
	"power_factor": 0.97
}
```

## Simulator
The simulator posts synthetic meter readings to the backend.

### Example
```powershell
python simulator\meter_simulator.py --url http://127.0.0.1:8000/readings --meters 2 --interval 10 --duration 60
```

### Useful options
- `--meters` — number of meters to simulate
- `--meter-ids` — explicitly target meter IDs
- `--interval` — seconds between reading cycles
- `--duration` — total run time in seconds
- `--profile` — usage pattern (`low`, `balanced`, `high`, `mixed`)
- `--seed` — make runs reproducible

## Database
- Default local database: `dev.db`
- Connection string override: set `DATABASE_URL` in a `.env` file
- Alembic migration history lives in `alembic/versions/`

## Testing
Run the test suite with:

```powershell
pytest -q
```

## Troubleshooting
- If `uvicorn` cannot import the app, make sure you run commands from the project root.
- If you see a Pydantic warning about `orm_mode`, the app still runs; it is a v1-to-v2 compatibility warning.
- If dependency installation fails on a new Python version, try reinstalling using wheel-compatible package versions from `requirements.txt`.
- If the simulator gets `404` responses, confirm the backend is running and the URL points to `/readings/`.

## Roadmap
- Authentication and authorization
- Dashboard frontend
- Email/SMS alerts
- Docker Compose deployment
- PostgreSQL production setup
- Streaming/queue-based ingestion

## References
- `docs/architecture.md`
- `docs/api-endpoints.md`
- `docs/demo-steps.md`

## License
No license has been added yet. Add one before publishing or sharing externally.
