from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class HouseholdCreate(BaseModel):
    customer_name: str
    email: str
    phone: Optional[str]
    address: Optional[str]

class HouseholdOut(HouseholdCreate):
    household_id: int
    created_at: datetime
    class Config:
        orm_mode = True

class MeterCreate(BaseModel):
    household_id: int
    meter_number: str


class MeterOut(MeterCreate):
    meter_id: int
    status: Optional[str] = "ACTIVE"
    installed_date: Optional[datetime]

    class Config:
        orm_mode = True

class ReadingCreate(BaseModel):
    meter_id: int
    energy_consumed_kwh: float = Field(..., gt=0)
    voltage: Optional[float]
    current: Optional[float]
    power_factor: Optional[float]


class ReadingOut(ReadingCreate):
    reading_id: int
    timestamp: datetime

    class Config:
        orm_mode = True

class AlertOut(BaseModel):
    alert_id: int
    household_id: Optional[int]
    meter_id: Optional[int]
    alert_type: str
    message: str
    severity: Optional[str]
    status: str
    created_at: datetime

    class Config:
        orm_mode = True


class AlertCreate(BaseModel):
    household_id: Optional[int] = None
    meter_id: Optional[int] = None
    alert_type: str
    message: str
    severity: str = "MEDIUM"
    status: str = "OPEN"


class BillEstimateOut(BaseModel):
    household_id: int
    total_kwh: float
    rate_per_kwh: float
    estimated_bill: float


class MonthlyReportOut(BaseModel):
    household_id: int
    total_kwh: float
    average_kwh: float
    peak_kwh: float
    reading_count: int
