from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from models.warehouse import Warehouse
from models.user import User
from routes.auth import get_current_actor
from schemas.warehouse import WarehouseCreate, WarehouseOut, WarehouseUpdate

router = APIRouter(prefix="/warehouses", tags=["Warehouses"])


@router.post("", response_model=WarehouseOut, status_code=201)
def create_warehouse(
    payload: WarehouseCreate,
    db: Session = Depends(get_db),
    actor: dict = Depends(get_current_actor),
):
    user_id = payload.user_id if actor["role"] == "admin" else actor["user_id"]

    if not db.get(User, user_id):
        raise HTTPException(
            status_code=404,
            detail="User not found"
        )

    existing_warehouse = db.query(Warehouse).filter(
        Warehouse.user_id == user_id,
        Warehouse.name == payload.name
    ).first()

    if existing_warehouse:
        raise HTTPException(
            status_code=400,
            detail="Warehouse already exists"
        )

    warehouse = Warehouse(
        name=payload.name,
        location=payload.location,
        user_id=user_id
    )

    db.add(warehouse)
    db.commit()
    db.refresh(warehouse)

    return warehouse


@router.get("", response_model=list[WarehouseOut])
def list_warehouses(db: Session = Depends(get_db), actor: dict = Depends(get_current_actor)):
    query = db.query(Warehouse)
    if actor["role"] != "admin":
        query = query.filter(Warehouse.user_id == actor["user_id"])
    return query.all()


@router.get("/{warehouse_id}", response_model=WarehouseOut)
def get_warehouse(
    warehouse_id: int,
    db: Session = Depends(get_db),
    actor: dict = Depends(get_current_actor),
):
    warehouse = db.get(Warehouse, warehouse_id)
    if not warehouse or (actor["role"] != "admin" and warehouse.user_id != actor["user_id"]):
        raise HTTPException(status_code=404, detail="Warehouse not found")
    return warehouse


@router.put("/{warehouse_id}", response_model=WarehouseOut)
def update_warehouse(
    warehouse_id: int,
    payload: WarehouseUpdate,
    db: Session = Depends(get_db),
    actor: dict = Depends(get_current_actor),
):
    warehouse = db.get(Warehouse, warehouse_id)
    if not warehouse or (actor["role"] != "admin" and warehouse.user_id != actor["user_id"]):
        raise HTTPException(status_code=404, detail="Warehouse not found")
    warehouse.name = payload.name # pyright: ignore[reportAttributeAccessIssue]
    warehouse.location = payload.location # pyright: ignore[reportAttributeAccessIssue]
    db.commit()
    db.refresh(warehouse)
    return warehouse


@router.delete("/{warehouse_id}")
def delete_warehouse(
    warehouse_id: int,
    db: Session = Depends(get_db),
    actor: dict = Depends(get_current_actor),
):
    warehouse = db.get(Warehouse, warehouse_id)
    if not warehouse or (actor["role"] != "admin" and warehouse.user_id != actor["user_id"]):
        raise HTTPException(status_code=404, detail="Warehouse not found")
    db.delete(warehouse)
    db.commit()
    return {"message": "Warehouse deleted"}
