from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from database import get_db
from models.storage_unit import StorageUnit
from models.warehouse import Warehouse
from routes.auth import get_current_actor
from services.analytics import (
    alert_type_distribution,
    alerts_by_day,
    compliance_report,
    problematic_storage_units,
    summary_counts,
    user_compliance,
    warehouse_compliance,
)

router = APIRouter(prefix="/reports", tags=["Reports"])


def _scope_ids(db: Session, actor: dict):
    if actor["role"] == "admin":
        return None, None, False
    warehouses = db.query(Warehouse).filter(Warehouse.user_id == actor["user_id"]).all()
    warehouse_ids = [warehouse.id for warehouse in warehouses]
    if not warehouse_ids:
        return [], [], True
    storage_unit_ids = [
        unit.id
        for unit in db.query(StorageUnit).filter(StorageUnit.warehouse_id.in_(warehouse_ids)).all()
    ]
    return warehouse_ids, storage_unit_ids, True


@router.get("/compliance")
def get_compliance_report(db: Session = Depends(get_db), actor: dict = Depends(get_current_actor)):
    _, storage_unit_ids, _ = _scope_ids(db, actor)
    return compliance_report(db, storage_unit_ids)


@router.get("/summary")
def get_summary_report(db: Session = Depends(get_db), actor: dict = Depends(get_current_actor)):
    warehouse_ids, storage_unit_ids, user_scope = _scope_ids(db, actor)
    return summary_counts(db, storage_unit_ids, warehouse_ids, user_scope=user_scope)


@router.get("/analytics")
def get_analytics_report(db: Session = Depends(get_db), actor: dict = Depends(get_current_actor)):
    warehouse_ids, storage_unit_ids, _ = _scope_ids(db, actor)
    user_ids = None if actor["role"] == "admin" else [actor["user_id"]]
    return {
        "alerts_by_day": alerts_by_day(db, storage_unit_ids),
        "most_problematic_storage_units": problematic_storage_units(db, storage_unit_ids),
        "alert_type_distribution": alert_type_distribution(db, storage_unit_ids),
        "warehouse_compliance": warehouse_compliance(db, warehouse_ids),
        "user_compliance": user_compliance(db, user_ids),
        "system_or_scope_compliance": compliance_report(db, storage_unit_ids),
    }
