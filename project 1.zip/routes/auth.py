from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from config import ADMIN_PASSWORD, ADMIN_USERNAME
from database import get_db
from models.user import User

router = APIRouter()
templates = Jinja2Templates(directory="templates")


@router.get("/", response_class=HTMLResponse)
@router.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse(
        request,
        "login.html",
        {"login_error": None, "register_error": None, "success": None, "register_username": ""},
    )


@router.get("/register", response_class=HTMLResponse)
def register_page(request: Request):
    return RedirectResponse("/login", status_code=303)


@router.post("/register")
async def register(request: Request, db: Session = Depends(get_db)):
    content_type = request.headers.get("content-type", "")
    if "application/json" in content_type:
        payload = await request.json()
        username = (payload.get("username") or "").strip()
        password = payload.get("password") or ""
        confirm_password = payload.get("confirm_password") or ""
    else:
        form = await request.form()
        username = (form.get("register_username") or "").strip()
        password = form.get("register_password") or ""
        confirm_password = form.get("confirm_password") or ""

    error = None
    if db.query(User).filter(User.username == username).first():
        error = "User already exists"
    elif not username:
        error = "Username cannot be empty"
    elif not password:
        error = "Password cannot be empty"
    elif password != confirm_password:
        error = "Passwords do not match"

    if error:
        if "application/json" in content_type:
            raise HTTPException(status_code=400, detail=error)
        return templates.TemplateResponse(
            request,
            "login.html",
            {
                "login_error": None,
                "register_error": error,
                "success": None,
                "register_username": username,
            },
            status_code=400,
        )

    user = User(username=username, password=password)
    db.add(user)
    db.commit()

    if "application/json" in content_type:
        return {"message": "Registration Successful. Please Login.", "redirect": "/login"}
    return templates.TemplateResponse(
        request,
        "login.html",
        {
            "login_error": None,
            "register_error": None,
            "success": "Registration Successful. Please Login.",
            "register_username": "",
        },
    )


@router.post("/login")
async def login(request: Request, db: Session = Depends(get_db)):
    content_type = request.headers.get("content-type", "")
    if "application/json" in content_type:
        payload = await request.json()
        username = payload.get("username")
        password = payload.get("password")
    else:
        form = await request.form()
        username = form.get("username")
        password = form.get("password")

    if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
        request.session["role"] = "admin"
        request.session["username"] = ADMIN_USERNAME
        if "application/json" in content_type:
            return {"message": "Admin login successful", "role": "admin", "redirect": "/admin/dashboard"}
        return RedirectResponse("/admin/dashboard", status_code=303)

    user = db.query(User).filter(User.username == username, User.password == password).first()
    if user:
        request.session["role"] = "user"
        request.session["user_id"] = user.id
        request.session["username"] = user.username
        if "application/json" in content_type:
            return {"message": "User login successful", "role": "user", "redirect": "/user/dashboard"}
        return RedirectResponse("/user/dashboard", status_code=303)

    if "application/json" in content_type:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    return templates.TemplateResponse(
        request,
        "login.html",
        {
            "login_error": "Invalid Username or Password",
            "register_error": None,
            "success": None,
            "register_username": "",
        },
        status_code=401,
    )


@router.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=303)


def require_admin(request: Request):
    if request.session.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")


def require_user(request: Request):
    if request.session.get("role") != "user":
        raise HTTPException(status_code=403, detail="User access required")
    return request.session["user_id"]


def get_current_actor(request: Request):
    role = request.session.get("role")
    if role == "admin":
        return {"role": "admin", "user_id": None}
    if role == "user" and request.session.get("user_id"):
        return {"role": "user", "user_id": request.session["user_id"]}
    raise HTTPException(status_code=403, detail="Login required")
