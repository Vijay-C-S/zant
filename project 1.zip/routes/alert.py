from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from models.alert import Alert
from models.storage_unit import StorageUnit
from models.warehouse import Warehouse
from routes.auth import get_current_actor
from schemas.alert import AlertOut

router = APIRouter(prefix="/alerts", tags=["Alerts"])


@router.get("", response_model=list[AlertOut])
def list_alerts(db: Session = Depends(get_db), actor: dict = Depends(get_current_actor)):
    query = db.query(Alert).join(StorageUnit).join(Warehouse)
    if actor["role"] != "admin":
        query = query.filter(Warehouse.user_id == actor["user_id"])
    return query.order_by(Alert.timestamp.desc()).all()


@router.get("/{alert_id}", response_model=AlertOut)
def get_alert(alert_id: int, db: Session = Depends(get_db), actor: dict = Depends(get_current_actor)):
    alert = db.query(Alert).join(StorageUnit).join(Warehouse).filter(Alert.id == alert_id).first()
    if not alert or (actor["role"] != "admin" and alert.storage_unit.warehouse.user_id != actor["user_id"]):
        raise HTTPException(status_code=404, detail="Alert not found")
    return alert
