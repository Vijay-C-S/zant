from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from models.storage_unit import StorageUnit
from models.telemetry import Telemetry
from models.warehouse import Warehouse
from routes.auth import get_current_actor
from schemas.telemetry import TelemetryOut

router = APIRouter(prefix="/telemetry", tags=["Telemetry"])


@router.get("", response_model=list[TelemetryOut])
def list_telemetry(db: Session = Depends(get_db), actor: dict = Depends(get_current_actor)):
    query = db.query(Telemetry).join(StorageUnit).join(Warehouse)
    if actor["role"] != "admin":
        query = query.filter(Warehouse.user_id == actor["user_id"])
    return query.order_by(Telemetry.timestamp.desc()).all()


@router.get("/{telemetry_id}", response_model=TelemetryOut)
def get_telemetry(
    telemetry_id: int,
    db: Session = Depends(get_db),
    actor: dict = Depends(get_current_actor),
):
    telemetry = (
        db.query(Telemetry)
        .join(StorageUnit)
        .join(Warehouse)
        .filter(Telemetry.id == telemetry_id)
        .first()
    )
    if not telemetry or (actor["role"] != "admin" and telemetry.storage_unit.warehouse.user_id != actor["user_id"]):
        raise HTTPException(status_code=404, detail="Telemetry not found")
    return telemetry
