from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from models.storage_unit import StorageUnit
from models.warehouse import Warehouse
from routes.auth import get_current_actor
from schemas.storage_unit import StorageUnitCreate, StorageUnitOut, StorageUnitUpdate

router = APIRouter(prefix="/storage-units", tags=["Storage Units"])

@router.post("", response_model=StorageUnitOut, status_code=201)
def create_storage_unit(
    payload: StorageUnitCreate,
    db: Session = Depends(get_db),
    actor: dict = Depends(get_current_actor),
    ):
    warehouse = db.get(Warehouse, payload.warehouse_id)


    if not warehouse or (
        actor["role"] != "admin"
        and warehouse.user_id != actor["user_id"]
    ):
        raise HTTPException(
            status_code=404,
            detail="Warehouse not found"
        )

# Prevent duplicate storage units inside same warehouse
    existing_unit = (
        db.query(StorageUnit)
        .filter(
            StorageUnit.warehouse_id == payload.warehouse_id,
            StorageUnit.unit_name == payload.unit_name
        )
        .first()
    )

    if existing_unit:
        raise HTTPException(
            status_code=400,
            detail="Storage Unit already exists in this warehouse"
        )

    unit = StorageUnit(
        warehouse_id=payload.warehouse_id,
        unit_name=payload.unit_name
    )

    db.add(unit)
    db.commit()
    db.refresh(unit)

    return unit


@router.get("", response_model=list[StorageUnitOut])
def list_storage_units(
    db: Session = Depends(get_db),
    actor: dict = Depends(get_current_actor)
    ):
    query = db.query(StorageUnit).join(Warehouse)


    if actor["role"] != "admin":
        query = query.filter(
            Warehouse.user_id == actor["user_id"]
        )

    return query.all()


@router.get("/{storage_unit_id}", response_model=StorageUnitOut)
def get_storage_unit(
    storage_unit_id: int,
    db: Session = Depends(get_db),
    actor: dict = Depends(get_current_actor),
    ):
    unit = (
    db.query(StorageUnit)
    .join(Warehouse)
    .filter(StorageUnit.id == storage_unit_id)
    .first()
    )


    if not unit or (
        actor["role"] != "admin"
        and unit.warehouse.user_id != actor["user_id"]
    ):
        raise HTTPException(
            status_code=404,
            detail="Storage unit not found"
        )

    return unit


@router.put("/{storage_unit_id}", response_model=StorageUnitOut)
def update_storage_unit(
    storage_unit_id: int,
    payload: StorageUnitUpdate,
    db: Session = Depends(get_db),
    actor: dict = Depends(get_current_actor),
    ):
    # Admin only
    if actor["role"] != "admin":
        raise HTTPException(
            status_code=403,
            detail="Only admin can update storage units"
        )


    unit = db.get(StorageUnit, storage_unit_id)

    if not unit:
        raise HTTPException(
            status_code=404,
            detail="Storage unit not found"
        )

    unit.unit_name = payload.unit_name

    db.commit()
    db.refresh(unit)

    return unit


@router.delete("/{storage_unit_id}")
def delete_storage_unit(
    storage_unit_id: int,
    db: Session = Depends(get_db),
    actor: dict = Depends(get_current_actor),
    ):
    # Admin only
    if actor["role"] != "admin":
        raise HTTPException(
        status_code=403,
        detail="Only admin can delete storage units"
        )

    unit = db.get(StorageUnit, storage_unit_id)

    if not unit:
        raise HTTPException(
            status_code=404,
            detail="Storage unit not found"
        )

    db.delete(unit)
    db.commit()

    return {"message": "Storage unit deleted"}
