from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy.orm import joinedload
from models.alert import Alert
from models.user import User
from datetime import datetime

from database import get_db
from models.storage_unit import StorageUnit
from models.warehouse import Warehouse
from routes.auth import require_admin, require_user
from services.analytics import (
    alert_type_distribution,
    alerts_by_day,
    dashboard_insights,
    compliance_report,
    problematic_storage_units,
    summary_counts,
    warehouse_compliance,
)

router = APIRouter(tags=["Dashboards"])
templates = Jinja2Templates(directory="templates")


def _analytics_payload(db, warehouse_ids=None, storage_unit_ids=None, user_scope=False):
    return {
        "summary": summary_counts(
            db,
            storage_unit_ids,
            warehouse_ids,
            user_scope=user_scope
        ),
        "insights": dashboard_insights(
            db,
            warehouse_ids,
            storage_unit_ids
        ),
        "problem_units": problematic_storage_units(
            db,
            storage_unit_ids
        ),
        "alert_distribution": alert_type_distribution(
            db,
            storage_unit_ids
        ),
        "alerts_by_day": []
    }


@router.get("/admin/dashboard", response_class=HTMLResponse)
def admin_dashboard(
    request: Request,
    db: Session = Depends(get_db),
    _: None = Depends(require_admin)
):
    context = _analytics_payload(db)

    context["title"] = "Admin Dashboard"
    context["users"] = db.query(User).all()
    context["warehouses"] = db.query(Warehouse).all()
    context["storage_units"] = db.query(StorageUnit).all()
    recent_alerts = (
    db.query(Alert)
    .order_by(Alert.timestamp.desc())
    .limit(10)
    .all()
)
    context["recent_alerts"] = recent_alerts
    return templates.TemplateResponse(
        request,
        "admin_dashboard.html",
        context
    )



@router.get("/user/dashboard", response_class=HTMLResponse)
def user_dashboard(request: Request, db: Session = Depends(get_db), user_id: int = Depends(require_user)):
    warehouses = (
    db.query(Warehouse)
    .options(joinedload(Warehouse.storage_units))
    .filter(Warehouse.user_id == user_id)
    .all()
)
    warehouse_ids = [warehouse.id for warehouse in warehouses]
    storage_unit_ids = [
        unit.id
        for unit in db.query(StorageUnit).filter(StorageUnit.warehouse_id.in_(warehouse_ids)).all()
    ] if warehouse_ids else []
    context = _analytics_payload(db, warehouse_ids, storage_unit_ids, user_scope=True)
    context["title"] = "User Dashboard"
    context["username"] = request.session.get("username")
    context["warehouses"] = warehouses
    recent_alerts = (
    db.query(Alert)
    .join(StorageUnit)
    .join(Warehouse)
    .filter(Warehouse.user_id == user_id)
    .order_by(Alert.timestamp.desc())
    .limit(10)
    .all()
)

    context["recent_alerts"] = recent_alerts
    return templates.TemplateResponse(request, "user_dashboard.html", context)


@router.post("/user/warehouses")
def create_user_warehouse(
    name: str = Form(...),
    location: str = Form(...),
    db: Session = Depends(get_db),
    user_id: int = Depends(require_user),
):
    existing_warehouse = (
    db.query(Warehouse)
    .filter(
        Warehouse.user_id == user_id,
        Warehouse.name == name.strip()
    )
    .first()
)

    if existing_warehouse:
        return RedirectResponse(
            "/user/dashboard",
            status_code=303
        )
    warehouse = Warehouse(name=name.strip(), location=location.strip(), user_id=user_id)
    db.add(warehouse)
    db.commit()
    return RedirectResponse("/user/dashboard", status_code=303)




@router.post("/user/storage-units")
def create_user_storage_unit(
    warehouse_id: int = Form(...),
    unit_name: str = Form(...),
    db: Session = Depends(get_db),
    user_id: int = Depends(require_user),
):
    warehouse = db.query(Warehouse).filter(Warehouse.id == warehouse_id, Warehouse.user_id == user_id).first()
    if not warehouse:
        raise HTTPException(status_code=404, detail="Warehouse not found")
    existing_unit = (
    db.query(StorageUnit)
    .filter(
        StorageUnit.warehouse_id == warehouse.id,
        StorageUnit.unit_name == unit_name.strip()
        )
        .first()
    )

    if existing_unit:
        return RedirectResponse(
        "/user/dashboard",
        status_code=303
    )

    unit = StorageUnit(
        warehouse_id=warehouse.id,
        unit_name=unit_name.strip()
    )
    db.add(unit)
    db.commit()
    return RedirectResponse("/user/dashboard", status_code=303)

@router.post("/admin/users/{user_id}/delete")
def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    _: None = Depends(require_admin),
):
    user = db.get(User, user_id)

    if not user:
        raise HTTPException(
            status_code=404,
            detail="User not found"
        )

    # Prevent admin from deleting himself
    if user.username.lower() == "admin":
        raise HTTPException(
            status_code=400,
            detail="Admin account cannot be deleted"
        )

    db.delete(user)
    db.commit()

    return RedirectResponse(
        "/admin/dashboard",
        status_code=303
    )

@router.post("/admin/warehouses/{warehouse_id}/delete")
def delete_warehouse_admin(
    warehouse_id: int,
    db: Session = Depends(get_db),
    _: None = Depends(require_admin),
):
    warehouse = db.get(Warehouse, warehouse_id)

    if not warehouse:
        raise HTTPException(
            status_code=404,
            detail="Warehouse not found"
        )

    db.delete(warehouse)
    db.commit()

    return RedirectResponse(
        "/admin/dashboard",
        status_code=303
    )

@router.post("/admin/storage-units/{storage_unit_id}/delete")
def delete_storage_unit_admin(
    storage_unit_id: int,
    db: Session = Depends(get_db),
    _: None = Depends(require_admin),
):
    unit = db.get(StorageUnit, storage_unit_id)

    if not unit:
        raise HTTPException(
            status_code=404,
            detail="Storage unit not found"
        )

    db.delete(unit)
    db.commit()

    return RedirectResponse(
        "/admin/dashboard",
        status_code=303
    )


@router.post("/admin/warehouses/{warehouse_id}/update")
def update_warehouse_admin(
    warehouse_id: int,
    name: str = Form(...),
    location: str = Form(...),
    db: Session = Depends(get_db),
    _: None = Depends(require_admin),
):
    warehouse = db.get(Warehouse, warehouse_id)

    if not warehouse:
        raise HTTPException(
            status_code=404,
            detail="Warehouse not found"
        )
    name = name.strip()
    location = location.strip()

    if not name or not location:
        return RedirectResponse(
            "/admin/dashboard",
            status_code=303
        )
    existing_warehouse = (
    db.query(Warehouse)
    .filter(
        Warehouse.id != warehouse_id,
        Warehouse.user_id == warehouse.user_id,
        Warehouse.name == name.strip()
    )
    .first()
    )

    if existing_warehouse:
        return RedirectResponse(
            "/admin/dashboard",
            status_code=303
        )
    warehouse.name = name.strip()
    warehouse.location = location.strip()

    db.commit()

    return RedirectResponse(
        "/admin/dashboard",
        status_code=303
    )


@router.post("/admin/storage-units/{storage_unit_id}/update")
def update_storage_unit_admin(
    storage_unit_id: int,
    unit_name: str = Form(...),
    db: Session = Depends(get_db),
    _: None = Depends(require_admin),
):
    unit = db.get(StorageUnit, storage_unit_id)

    if not unit:
        raise HTTPException(
            status_code=404,
            detail="Storage unit not found"
        )
    unit_name = unit_name.strip()

    if not unit_name:
        return RedirectResponse(
            "/admin/dashboard",
            status_code=303
        )
    existing_unit = (
    db.query(StorageUnit)
    .filter(
        StorageUnit.id != storage_unit_id,
        StorageUnit.warehouse_id == unit.warehouse_id,
        StorageUnit.unit_name == unit_name.strip()
    )
    .first()
)

    if existing_unit:
        return RedirectResponse(
            "/admin/dashboard",
            status_code=303
        )
    unit.unit_name = unit_name.strip()

    db.commit()

    return RedirectResponse(
        "/admin/dashboard",
        status_code=303
    )

@router.post("/admin/alerts/{alert_id}/resolve")
def resolve_alert(
    alert_id: int,
    db: Session = Depends(get_db),
    _: None = Depends(require_admin),
):
    alert = db.get(Alert, alert_id)
 
    if not alert:
        raise HTTPException(
            status_code=404,
            detail="Alert not found"
        )
 
    alert.resolved = True
    alert.resolved_at = datetime.utcnow()
 
    db.commit()
 
    return RedirectResponse(
        "/admin/dashboard",
        status_code=303
    )

 