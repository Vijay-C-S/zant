import os
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

from database import SessionLocal, init_db
from models.storage_unit import StorageUnit
from models.telemetry import Telemetry
from models.user import User
from models.warehouse import Warehouse
from routes import alert, auth, dashboard, reports, storage_unit, telemetry, user, warehouse
from services.monitoring import evaluate_telemetry
from services.sensor_simulator import start_background_simulator, stop_background_simulator



@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    if os.getenv("DISABLE_SENSOR_SIMULATOR") != "1":
        start_background_simulator()
    yield
    stop_background_simulator()


app = FastAPI(title="Cold Storage Monitoring System", version="1.0.0", lifespan=lifespan)
app.add_middleware(SessionMiddleware, secret_key="cold-storage-monitoring-secret")
app.mount("/static", StaticFiles(directory="static"), name="static")

app.include_router(auth.router)
app.include_router(user.router)
app.include_router(warehouse.router)
app.include_router(storage_unit.router)
app.include_router(telemetry.router)
app.include_router(alert.router)
app.include_router(reports.router)
app.include_router(dashboard.router)
