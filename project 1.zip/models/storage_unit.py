from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from database import Base


class StorageUnit(Base):
    __tablename__ = "storage_units"

    id = Column(Integer, primary_key=True, index=True)
    warehouse_id = Column(Integer, ForeignKey("warehouses.id"), nullable=False)
    unit_name = Column(String, nullable=False)

    warehouse = relationship("Warehouse", back_populates="storage_units")
    telemetry_records = relationship("Telemetry", back_populates="storage_unit", cascade="all, delete-orphan")
    alerts = relationship("Alert", back_populates="storage_unit", cascade="all, delete-orphan")
