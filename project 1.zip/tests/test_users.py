import os
from uuid import uuid4

os.environ["DISABLE_SENSOR_SIMULATOR"] = "1"

from fastapi.testclient import TestClient

from app import app

client = TestClient(app)


def test_create_list_get_and_delete_user():
    local_client = TestClient(app)
    username = f"user_{uuid4().hex[:8]}"
    create_response = local_client.post("/users", json={"username": username, "password": "pass123"})

    assert create_response.status_code == 201
    created = create_response.json()
    assert created["username"] == username
    assert "password" not in created

    local_client.post("/login", data={"username": "admin", "password": "admin123"})

    list_response = local_client.get("/users")
    assert list_response.status_code == 200
    assert any(user["id"] == created["id"] for user in list_response.json())

    get_response = local_client.get(f"/users/{created['id']}")
    assert get_response.status_code == 200
    assert get_response.json()["username"] == username

    delete_response = local_client.delete(f"/users/{created['id']}")
    assert delete_response.status_code == 200
    assert delete_response.json()["message"] == "User deleted"


def test_register_new_user_and_login():
    username = f"register_{uuid4().hex[:8]}"

    register_response = client.post(
        "/register",
        data={
            "register_username": username,
            "register_password": "pass123",
            "confirm_password": "pass123",
        },
    )
    assert register_response.status_code == 200
    assert "Registration Successful" in register_response.text
    assert "Please Login" in register_response.text

    login_response = client.post(
        "/login",
        data={"username": username, "password": "pass123"},
        follow_redirects=True,
    )
    assert login_response.status_code == 200
    assert "User Dashboard" in login_response.text


def test_login_page_hides_registration_by_default():
    response = client.get("/login")

    assert response.status_code == 200
    assert 'id="registerSection"' in response.text
    assert 'class="register-section"' in response.text
    assert "Register Here" in response.text


def test_register_validation_errors():
    username = f"duplicate_{uuid4().hex[:8]}"
    first_response = client.post(
        "/register",
        data={
            "register_username": username,
            "register_password": "pass123",
            "confirm_password": "pass123",
        },
    )
    assert first_response.status_code == 200

    duplicate_response = client.post(
        "/register",
        data={
            "register_username": username,
            "register_password": "pass123",
            "confirm_password": "pass123",
        },
    )
    assert duplicate_response.status_code == 400
    assert "User already exists" in duplicate_response.text

    mismatch_response = client.post(
        "/register",
        data={
            "register_username": f"mismatch_{uuid4().hex[:8]}",
            "register_password": "pass123",
            "confirm_password": "different",
        },
    )
    assert mismatch_response.status_code == 400
    assert "Passwords do not match" in mismatch_response.text

    empty_username_response = client.post(
        "/register",
        data={
            "register_username": "",
            "register_password": "pass123",
            "confirm_password": "pass123",
        },
    )
    assert empty_username_response.status_code == 400
    assert "Username cannot be empty" in empty_username_response.text

    empty_password_response = client.post(
        "/register",
        data={
            "register_username": f"empty_{uuid4().hex[:8]}",
            "register_password": "",
            "confirm_password": "",
        },
    )
    assert empty_password_response.status_code == 400
    assert "Password cannot be empty" in empty_password_response.text


def test_json_registration_for_dynamic_login_page():
    username = f"json_register_{uuid4().hex[:8]}"

    register_response = client.post(
        "/register",
        json={
            "username": username,
            "password": "pass123",
            "confirm_password": "pass123",
        },
    )
    assert register_response.status_code == 200
    assert register_response.json()["message"] == "Registration Successful. Please Login."

    duplicate_response = client.post(
        "/register",
        json={
            "username": username,
            "password": "pass123",
            "confirm_password": "pass123",
        },
    )
    assert duplicate_response.status_code == 400
    assert duplicate_response.json()["detail"] == "User already exists"


def test_register_page_redirects_to_login():
    response = client.get("/register", follow_redirects=False)
    assert response.status_code == 303
    assert response.headers["location"] == "/login"


def test_logout_clears_session():
    username = f"logout_{uuid4().hex[:8]}"
    client.post(
        "/register",
        data={
            "register_username": username,
            "register_password": "pass123",
            "confirm_password": "pass123",
        },
    )
    client.post("/login", data={"username": username, "password": "pass123"})

    logout_response = client.get("/logout", follow_redirects=False)
    assert logout_response.status_code == 303
    assert logout_response.headers["location"] == "/login"

    dashboard_response = client.get("/user/dashboard")
    assert dashboard_response.status_code == 403
