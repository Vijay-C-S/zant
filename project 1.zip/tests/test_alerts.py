import os

os.environ["DISABLE_SENSOR_SIMULATOR"] = "1"

from fastapi.testclient import TestClient

from app import app
from app import seed_data
from database import SessionLocal, init_db
from models.storage_unit import StorageUnit
from models.telemetry import Telemetry
from services.monitoring import evaluate_telemetry

client = TestClient(app)


def test_alerts_are_created_for_unsafe_telemetry():
    local_client = TestClient(app)
    init_db()
    seed_data()
    db = SessionLocal()
    try:
        unit = db.query(StorageUnit).first()
        reading = Telemetry(
            storage_unit_id=unit.id,
            temperature=11.0,
            humidity=70.0,
            door_status="OPEN",
        )
        db.add(reading)
        db.flush()
        alerts = evaluate_telemetry(db, reading)
        db.commit()
        alert_ids = [alert.id for alert in alerts]
    finally:
        db.close()

    assert len(alert_ids) == 3

    local_client.post("/login", data={"username": "admin", "password": "admin123"})
    list_response = local_client.get("/alerts")
    assert list_response.status_code == 200
    assert any(alert["id"] in alert_ids for alert in list_response.json())

    detail_response = local_client.get(f"/alerts/{alert_ids[0]}")
    assert detail_response.status_code == 200
    assert detail_response.json()["alert_type"] in {"TEMPERATURE", "HUMIDITY", "DOOR"}
