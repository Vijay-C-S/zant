import os
from uuid import uuid4

os.environ["DISABLE_SENSOR_SIMULATOR"] = "1"

from fastapi.testclient import TestClient

from app import app

client = TestClient(app)


def test_create_list_get_and_delete_warehouse():
    local_client = TestClient(app)
    username = f"owner_{uuid4().hex[:8]}"
    user = local_client.post("/users", json={"username": username, "password": "pass123"}).json()
    local_client.post("/login", data={"username": username, "password": "pass123"})

    payload = {"name": "Test Cold Room", "location": "Pune", "user_id": user["id"]}
    create_response = local_client.post("/warehouses", json=payload)

    assert create_response.status_code == 201
    created = create_response.json()
    assert created["name"] == payload["name"]
    assert created["user_id"] == user["id"]

    list_response = local_client.get("/warehouses")
    assert list_response.status_code == 200
    assert any(warehouse["id"] == created["id"] for warehouse in list_response.json())

    get_response = local_client.get(f"/warehouses/{created['id']}")
    assert get_response.status_code == 200
    assert get_response.json()["location"] == "Pune"

    update_response = local_client.put(
        f"/warehouses/{created['id']}",
        json={"name": "Updated Cold Room", "location": "Mumbai"},
    )
    assert update_response.status_code == 200
    assert update_response.json()["name"] == "Updated Cold Room"

    delete_response = local_client.delete(f"/warehouses/{created['id']}")
    assert delete_response.status_code == 200
