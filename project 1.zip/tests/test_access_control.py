import os
from uuid import uuid4

os.environ["DISABLE_SENSOR_SIMULATOR"] = "1"

from fastapi.testclient import TestClient

from app import app
from database import SessionLocal
from models.telemetry import Telemetry


def _register_and_login(username):
    client = TestClient(app)
    client.post("/users", json={"username": username, "password": "pass123"})
    client.post("/login", data={"username": username, "password": "pass123"})
    return client


def test_users_only_see_their_own_operational_data():
    owner_name = f"owner_{uuid4().hex[:8]}"
    other_name = f"other_{uuid4().hex[:8]}"
    owner = _register_and_login(owner_name)
    other = _register_and_login(other_name)

    owner_warehouse = owner.post(
        "/warehouses",
        json={"name": "Owner Warehouse", "location": "Delhi", "user_id": 999999},
    ).json()
    other_warehouse = other.post(
        "/warehouses",
        json={"name": "Other Warehouse", "location": "Pune", "user_id": 999999},
    ).json()

    owner_unit = owner.post(
        "/storage-units",
        json={"warehouse_id": owner_warehouse["id"], "unit_name": "Owner Unit"},
    ).json()
    other_unit = other.post(
        "/storage-units",
        json={"warehouse_id": other_warehouse["id"], "unit_name": "Other Unit"},
    ).json()

    assert owner.get(f"/warehouses/{other_warehouse['id']}").status_code == 404
    assert owner.get(f"/storage-units/{other_unit['id']}").status_code == 404
    assert owner.post(
        "/storage-units",
        json={"warehouse_id": other_warehouse["id"], "unit_name": "Blocked Unit"},
    ).status_code == 404

    owner_warehouses = owner.get("/warehouses").json()
    assert owner_warehouse["id"] in [warehouse["id"] for warehouse in owner_warehouses]
    assert other_warehouse["id"] not in [warehouse["id"] for warehouse in owner_warehouses]

    db = SessionLocal()
    try:
        other_reading = Telemetry(
            storage_unit_id=other_unit["id"],
            temperature=5.0,
            humidity=50.0,
            door_status="CLOSED",
        )
        db.add(other_reading)
        db.commit()
        db.refresh(other_reading)
        other_telemetry_id = other_reading.id
    finally:
        db.close()

    assert owner.get(f"/telemetry/{other_telemetry_id}").status_code == 404
    assert other_unit["id"] not in [unit["id"] for unit in owner.get("/storage-units").json()]

    admin = TestClient(app)
    admin.post("/login", data={"username": "admin", "password": "admin123"})
    assert admin.get(f"/warehouses/{other_warehouse['id']}").status_code == 200
