from models.alert import Alert
from models.telemetry import Telemetry
from config import HUMIDITY_MAX, HUMIDITY_MIN, TEMP_MAX, TEMP_MIN

def is_safe_reading(telemetry: Telemetry) -> bool:
    return (
        TEMP_MIN <= telemetry.temperature <= TEMP_MAX
        and HUMIDITY_MIN <= telemetry.humidity <= HUMIDITY_MAX
        and telemetry.door_status == "CLOSED"
    )

def evaluate_telemetry(db, telemetry: Telemetry):
    alerts = []

    if telemetry.temperature < TEMP_MIN:
        alerts.append(
            Alert(
                storage_unit_id=telemetry.storage_unit_id,
                alert_type="TEMPERATURE",
                message=f"Temperature below safe range: {telemetry.temperature:.2f} C",
                severity="HIGH",
                timestamp=telemetry.timestamp,
            )
        )

    elif telemetry.temperature > TEMP_MAX:
        alerts.append(
            Alert(
                storage_unit_id=telemetry.storage_unit_id,
                alert_type="TEMPERATURE",
                message=f"Temperature above safe range: {telemetry.temperature:.2f} C",
                severity="HIGH",
                timestamp=telemetry.timestamp,
            )
        )

    if telemetry.humidity < HUMIDITY_MIN:
        alerts.append(
            Alert(
                storage_unit_id=telemetry.storage_unit_id,
                alert_type="HUMIDITY",
                message=f"Humidity below safe range: {telemetry.humidity:.2f}%",
                severity="MEDIUM",
                timestamp=telemetry.timestamp,
            )
        )

    elif telemetry.humidity > HUMIDITY_MAX:
        alerts.append(
            Alert(
                storage_unit_id=telemetry.storage_unit_id,
                alert_type="HUMIDITY",
                message=f"Humidity above safe range: {telemetry.humidity:.2f}%",
                severity="MEDIUM",
                timestamp=telemetry.timestamp,
            )
        )

    if telemetry.door_status == "OPEN":
        alerts.append(
            Alert(
                storage_unit_id=telemetry.storage_unit_id,
                alert_type="DOOR",
                message="Storage unit door is open",
                severity="CRITICAL",
                timestamp=telemetry.timestamp,
            )
        )

    for alert in alerts:
        db.add(alert)

    return alerts