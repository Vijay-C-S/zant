from sqlalchemy import func

from models.alert import Alert
from models.storage_unit import StorageUnit
from models.telemetry import Telemetry
from models.user import User
from models.warehouse import Warehouse
from services.monitoring import is_safe_reading


def alerts_by_day(db, storage_unit_ids=None):
    query = db.query(func.date(Alert.timestamp), func.count(Alert.id))
    if storage_unit_ids is not None:
        query = query.filter(Alert.storage_unit_id.in_(storage_unit_ids))
    rows = query.group_by(func.date(Alert.timestamp)).order_by(func.date(Alert.timestamp)).all()
    return [{"date": str(day), "alert_count": count} for day, count in rows]


def problematic_storage_units(db, storage_unit_ids=None):
    query = (
        db.query(StorageUnit.unit_name, func.count(Alert.id))
        .join(Alert, Alert.storage_unit_id == StorageUnit.id)
    )
    if storage_unit_ids is not None:
        query = query.filter(StorageUnit.id.in_(storage_unit_ids))
    rows = query.group_by(StorageUnit.id).order_by(func.count(Alert.id).desc()).all()
    return [{"storage_unit": name, "alert_count": count} for name, count in rows]


def alert_type_distribution(db, storage_unit_ids=None):
    query = db.query(Alert.alert_type, func.count(Alert.id))
    if storage_unit_ids is not None:
        query = query.filter(Alert.storage_unit_id.in_(storage_unit_ids))
    counts = {"TEMPERATURE": 0, "HUMIDITY": 0, "DOOR": 0}
    for alert_type, count in query.group_by(Alert.alert_type).all():
        counts[alert_type] = count
    return [{"alert_type": key, "count": value} for key, value in counts.items()]


def warehouse_compliance(db, warehouse_ids=None):
    warehouses = db.query(Warehouse)
    if warehouse_ids is not None:
        warehouses = warehouses.filter(Warehouse.id.in_(warehouse_ids))

    result = []
    for warehouse in warehouses.all():
        total = 0
        safe = 0
        for unit in warehouse.storage_units:
            for reading in unit.telemetry_records:
                total += 1
                safe += 1 if is_safe_reading(reading) else 0
        percentage = round((safe / total * 100), 2) if total else 100.0
        result.append(
            {
                "warehouse": warehouse.name,
                "total_readings": total,
                "safe_readings": safe,
                "unsafe_readings": total - safe,
                "compliance_percentage": percentage,
            }
        )
    return result


def user_compliance(db, user_ids=None):
    users = db.query(User)
    if user_ids is not None:
        users = users.filter(User.id.in_(user_ids))

    result = []
    for user in users.all():
        total = 0
        safe = 0
        for warehouse in user.warehouses:
            for unit in warehouse.storage_units:
                for reading in unit.telemetry_records:
                    total += 1
                    safe += 1 if is_safe_reading(reading) else 0
        result.append(
            {
                "user": user.username,
                "total_readings": total,
                "safe_readings": safe,
                "unsafe_readings": total - safe,
                "compliance_percentage": round((safe / total * 100), 2) if total else 100.0,
            }
        )
    return result


def summary_counts(db, storage_unit_ids=None, warehouse_ids=None, user_scope=False):
    telemetry_query = db.query(Telemetry)
    alert_query = db.query(Alert)
    unit_query = db.query(StorageUnit)
    warehouse_query = db.query(Warehouse)

    if storage_unit_ids is not None:
        telemetry_query = telemetry_query.filter(Telemetry.storage_unit_id.in_(storage_unit_ids))
        alert_query = alert_query.filter(Alert.storage_unit_id.in_(storage_unit_ids))
        unit_query = unit_query.filter(StorageUnit.id.in_(storage_unit_ids))
    if warehouse_ids is not None:
        warehouse_query = warehouse_query.filter(Warehouse.id.in_(warehouse_ids))

    return {
        "total_warehouses": warehouse_query.count(),
        "total_storage_units": unit_query.count(),
        "total_telemetry_records": telemetry_query.count(),
        "total_alerts": alert_query.count(),
        "total_users": None if user_scope else db.query(func.count()).select_from(User).scalar(),
    }


def dashboard_insights(db, warehouse_ids=None, storage_unit_ids=None):
    units = problematic_storage_units(db, storage_unit_ids)
    alert_types = alert_type_distribution(db, storage_unit_ids)
    compliance = warehouse_compliance(db, warehouse_ids)
    days = alerts_by_day(db, storage_unit_ids)

    most_problematic = units[0]["storage_unit"] if units else "No alerts"
    common_alert = max(alert_types, key=lambda item: item["count"]) if alert_types else None
    sorted_compliance = sorted(compliance, key=lambda item: item["compliance_percentage"])
    max_day = max(days, key=lambda item: item["alert_count"]) if days else None

    return {
        "most_problematic_storage_unit": most_problematic,
        "most_common_alert_type": common_alert["alert_type"] if common_alert and common_alert["count"] else "No alerts",
        "best_warehouse": sorted_compliance[-1]["warehouse"] if sorted_compliance else "No warehouse",
        "worst_warehouse": sorted_compliance[0]["warehouse"] if sorted_compliance else "No warehouse",
        "day_with_maximum_alerts": max_day["date"] if max_day else "No alerts",
    }


def compliance_report(db, storage_unit_ids=None):
    query = db.query(Telemetry)
    if storage_unit_ids is not None:
        query = query.filter(Telemetry.storage_unit_id.in_(storage_unit_ids))
    readings = query.all()
    total = len(readings)
    safe = sum(1 for reading in readings if is_safe_reading(reading))
    return {
        "total_readings": total,
        "safe_readings": safe,
        "unsafe_readings": total - safe,
        "compliance_percentage": round((safe / total * 100), 2) if total else 100.0,
    }
