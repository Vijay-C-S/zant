import random
import threading
import time
from datetime import datetime, timezone

from config import SENSOR_INTERVAL_SECONDS
from database import SessionLocal
from models.storage_unit import StorageUnit
from models.telemetry import Telemetry
from services.monitoring import evaluate_telemetry

_stop_event = threading.Event()
_thread = None


def generate_reading(db, storage_unit):
    telemetry = Telemetry(
        storage_unit_id=storage_unit.id,
        temperature=round(random.uniform(-1.0, 12.0), 2),
        humidity=round(random.uniform(30.0, 75.0), 2),
        door_status=random.choice(["OPEN", "CLOSED", "CLOSED"]),
        timestamp=datetime.now(timezone.utc),
    )
    db.add(telemetry)
    db.flush()
    evaluate_telemetry(db, telemetry)
    db.commit()
    db.refresh(telemetry)
    return telemetry


def generate_for_all_units():
    db = SessionLocal()
    try:
        units = db.query(StorageUnit).all()
        for unit in units:
            generate_reading(db, unit)
    finally:
        db.close()


def _run_loop():
    while not _stop_event.is_set():
        generate_for_all_units()
        _stop_event.wait(SENSOR_INTERVAL_SECONDS)


def start_background_simulator():
    global _thread
    if _thread and _thread.is_alive():
        return
    _stop_event.clear()
    _thread = threading.Thread(target=_run_loop, daemon=True)
    _thread.start()


def stop_background_simulator():
    _stop_event.set()
