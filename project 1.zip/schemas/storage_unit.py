from pydantic import BaseModel, ConfigDict


class StorageUnitCreate(BaseModel):
    warehouse_id: int
    unit_name: str


class StorageUnitUpdate(BaseModel):
    unit_name: str


class StorageUnitOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    warehouse_id: int
    unit_name: str
