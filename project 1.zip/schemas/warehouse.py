from pydantic import BaseModel, ConfigDict


class WarehouseCreate(BaseModel):
    name: str
    location: str
    user_id: int


class WarehouseUpdate(BaseModel):
    name: str
    location: str


class WarehouseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    location: str
    user_id: int
