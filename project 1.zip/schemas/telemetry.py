from datetime import datetime

from pydantic import BaseModel, ConfigDict


class TelemetryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    storage_unit_id: int
    temperature: float
    humidity: float
    door_status: str
    timestamp: datetime
