from datetime import datetime

from pydantic import BaseModel, ConfigDict


class AlertOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    storage_unit_id: int
    alert_type: str
    message: str
    severity: str
    timestamp: datetime
