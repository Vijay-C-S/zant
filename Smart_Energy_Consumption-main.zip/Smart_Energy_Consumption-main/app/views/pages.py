from fastapi import APIRouter
from fastapi.responses import HTMLResponse
import os

router = APIRouter(include_in_schema=False)
_TEMPLATE = os.path.join(os.path.dirname(__file__), "..", "..", "templates", "index.html")


@router.get("/", response_class=HTMLResponse)
def dashboard():
    with open(_TEMPLATE, encoding="utf-8") as f:
        return f.read()
